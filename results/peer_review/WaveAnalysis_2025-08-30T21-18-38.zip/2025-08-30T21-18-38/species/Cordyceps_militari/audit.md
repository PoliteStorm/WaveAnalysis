# Audit: Cordyceps_militari | 2025-08-22T00:41:09
- Channel: `diff_1`
- Created by: joe knowles | Intended for: peer_review
- Git SHA: 957ed7079b62f798597e084f7e02c8c80a7651bb
- Params: fs=1.0, min_amp_mV=0.1, min_isi_s=120.0, baseline_win_s=600.0
- τ grid: [5.5, 24.5, 104.0] | nu0≈17
- Compliance: OK